package be.kdg.battleship;

public class MainHack {
    public static void main(String[] args) {
        Main.main(args);
    }
}
