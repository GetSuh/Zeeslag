Player vs Computer werkt niet!
